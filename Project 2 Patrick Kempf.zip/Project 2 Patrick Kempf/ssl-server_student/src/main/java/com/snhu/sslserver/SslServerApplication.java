package com.snhu.sslserver;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.tomcat.util.buf.HexUtils;
import org.apache.commons.codec.digest.DigestUtils;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
@RestController
class ServerController {
    @RequestMapping("/hash")
    public String myHash() throws NoSuchAlgorithmException {
        String data = "Patrick Kempf";
        MessageDigest msgDigest = MessageDigest.getInstance("SHA3-256");
        byte[] byteArr = msgDigest.digest(data.getBytes());
        String checksum = HexUtils.toHexString(byteArr);
        
        String shahex = DigestUtils.sha3_256Hex(data);
        boolean shacompare = checksum.equals(shahex);
        
        return "<p>data: " + data + "</p>" +
               "<p>checksum: " + checksum + "</p>" +
               "<p>shahex: "+shahex+"</p>"+
               "<p>Same? "+shacompare+"</p>";
    }
}